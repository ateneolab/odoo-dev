# -*- coding: utf-8 -*-
import invoice_discount
import sale_discount