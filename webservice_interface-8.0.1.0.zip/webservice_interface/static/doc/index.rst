This module adds the option to easily configure a web service.
Besides the webservice definition no configuration is needed.

Creation of the webservice can be done here:

	**Settings > Technical > Web Services**

|

**Contact us:**

When you have any remark about this module, please let us know on http://www.onestein.eu/feedback
